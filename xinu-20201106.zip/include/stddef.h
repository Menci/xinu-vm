#ifndef _stddef_H
#define _stddef_H
/* stddef.h */

/* TEMPORARY */

/* Function declaration return types */
typedef void exchandler;        /**< exception procedure                */
typedef int message;            /**< message passing content            */

#endif

