#ifndef _heap_H
#define _heap_H

#include <xinu.h>

void changeHeapSize(int32 delta);

#endif // _heap_H
